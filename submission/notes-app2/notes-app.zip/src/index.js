import "../components/notes-app.js";
import "./styles.css";
